(() => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));
  let csrfToken = null;

  function isFriendsPage() {
    return location.pathname.includes("/friends");
  }

  async function getCsrf() {
    if (csrfToken) return csrfToken;

    const res = await fetch("https://friends.roblox.com/v1/users/1/unfriend", {
      method: "POST",
      credentials: "include"
    });

    csrfToken = res.headers.get("x-csrf-token");
    return csrfToken;
  }

  function getFriendCards() {
    return [...document.querySelectorAll("li")]
      .filter(li =>
        li.querySelector('a[href^="/users/"]') &&
        li.offsetParent !== null
      );
  }

  function injectCheckbox(card) {
    if (card.querySelector(".ru-checkbox")) return;

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.className = "ru-checkbox";

    Object.assign(cb.style, {
      marginRight: "8px",
      transform: "scale(1.2)",
      cursor: "pointer"
    });

    const link = card.querySelector('a[href^="/users/"]');
    link.parentElement.prepend(cb);
  }

  function extractLiveUserIdFromCheckbox(cb) {
    const card = cb.closest("li");
    if (!card) return null;

    const link = card.querySelector('a[href^="/users/"]');
    if (!link) return null;

    const match = link.getAttribute("href").match(/\/users\/(\d+)/);
    return match ? match[1] : null;
  }

  async function unfriend(userId) {
    const token = await getCsrf();

    const res = await fetch(
      `https://friends.roblox.com/v1/users/${userId}/unfriend`,
      {
        method: "POST",
        credentials: "include",
        headers: {
          "x-csrf-token": token
        }
      }
    );

    if (res.status === 403) {
      csrfToken = res.headers.get("x-csrf-token");
      return unfriend(userId);
    }
  }

  function addButton() {
    if (document.getElementById("ru-unfriend-btn")) return;

    const btn = document.createElement("button");
    btn.id = "ru-unfriend-btn";
    btn.textContent = "Unfriend Selected";

    Object.assign(btn.style, {
      position: "fixed",
      top: "90px",
      right: "20px",
      zIndex: 9999,
      padding: "10px 14px",
      background: "#e53935",
      color: "#fff",
      border: "none",
      borderRadius: "8px",
      fontWeight: "600",
      cursor: "pointer"
    });

    btn.onclick = async () => {
      const checked = [...document.querySelectorAll(".ru-checkbox:checked")];

      if (!checked.length) {
        alert("No users selected.");
        return;
      }

      // SAFETY CONFIRM: show usernames before unfriending
      const preview = checked
        .map(cb => {
          const card = cb.closest("li");
          return card?.innerText?.split("\n")[0];
        })
        .filter(Boolean)
        .join("\n");

      if (!confirm(`You are about to unfriend:\n\n${preview}`)) return;

      btn.disabled = true;
      btn.textContent = "Working...";

      for (const cb of checked) {
        const userId = extractLiveUserIdFromCheckbox(cb);
        if (!userId) continue;

        await unfriend(userId);
        await sleep(700);
      }

      location.reload();
    };

    document.body.appendChild(btn);
  }

  function scan() {
    if (!isFriendsPage()) return;
    getFriendCards().forEach(injectCheckbox);
    addButton();
  }

  const observer = new MutationObserver(scan);
  observer.observe(document.body, { childList: true, subtree: true });

  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      setTimeout(scan, 800);
    }
  }, 500);

  scan();
})();
